Core/Src/lateral_izquierda.o: ../Core/Src/lateral_izquierda.c
